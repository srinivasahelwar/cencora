# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

# Sandbox table only. Re-running resets the exercise data.
table = f"{ns}.day19_delta_demo"
(spark.table(f"{ns}.day19_silver").write.format("delta")
 .mode("overwrite").option("overwriteSchema", "true").saveAsTable(table))
before = spark.sql(f"DESCRIBE HISTORY {table}").first()["version"]
spark.sql(f"UPDATE {table} SET amount = 220.0 WHERE order_id = 2")
assert spark.sql(f"SELECT SUM(amount) FROM {table}").first()[0] == 1420.0
old = spark.sql(f"SELECT * FROM {table} VERSION AS OF {before}")
assert old.agg(F.sum("amount")).first()[0] == 1400.0
display(spark.sql(f"DESCRIBE HISTORY {table}"))
# RESTORE creates a new commit. It does not erase intervening history.
spark.sql(f"RESTORE TABLE {table} TO VERSION AS OF {before}")
assert spark.table(table).agg(F.sum("amount")).first()[0] == 1400.0
# Unexpected column: schema enforcement should reject this append.
extra = spark.table(table).filter("order_id = 1").withColumn("channel", F.lit("app"))
try:
    extra.write.format("delta").mode("append").saveAsTable(table)
except Exception as e:
    msg = str(e)
    if not any(x in msg.lower() for x in ["schema", "merge", "column"]):
        raise
    print("Expected schema rejection:", msg[:500])
else:
    raise AssertionError("Unexpected acceptance: check automatic schema evolution settings")
# Explicitly approve one new column and add a new order, not a duplicate.
new = extra.withColumn("order_id", F.lit(7)).withColumn("ingest_seq", F.lit(9))
(new.write.format("delta").mode("append")
 .option("mergeSchema", "true").saveAsTable(table))
assert "channel" in spark.table(table).columns
assert spark.table(table).count() == 7
assert spark.table(table).filter("channel IS NULL").count() == 6
# Replay-safe upsert example: an update to order 7, source has one row per key.
new.withColumn("amount", F.lit(120.0)).createOrReplaceTempView("day19_change")
merge_sql = f"""MERGE INTO {table} AS t USING day19_change AS s
ON t.order_id = s.order_id
WHEN MATCHED THEN UPDATE SET t.amount = s.amount
WHEN NOT MATCHED THEN INSERT *"""
spark.sql(merge_sql)
spark.sql(merge_sql)
assert spark.table(table).count() == 7
assert spark.table(table).agg(F.sum("amount")).first()[0] == 1520.0
print("PASS: time travel, restore, enforcement, evolution and MERGE")
# Inspect layout. OPTIMIZE is optional for this tiny table.
display(spark.sql(f"DESCRIBE DETAIL {table}"))
# spark.sql(f"OPTIMIZE {table}")
