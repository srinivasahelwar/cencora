# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

dbutils.widgets.dropdown("simulate_failure", "false", ["false", "true"])
if dbutils.widgets.get("simulate_failure") == "true":
    raise RuntimeError("Intentional classroom failure before writes")
b = spark.table(f"{ns}.day19_bronze")
valid = (F.col("order_id").isNotNull() &
         F.col("amount").isNotNull() & (F.col("amount") >= 0) &
         F.col("delivery_hours").isNotNull() &
         (F.col("delivery_hours") >= 0) &
         F.col("promised_hours").isNotNull() &
         (F.col("promised_hours") > 0) &
         F.to_date("order_date").isNotNull() &
         F.col("city").isNotNull())
valid = F.coalesce(valid, F.lit(False))
(b.filter(~valid).write.format("delta").mode("overwrite")
 .saveAsTable(f"{ns}.day19_quarantine"))
w = Window.partitionBy("order_id").orderBy(F.desc("ingest_seq"))
s = (b.filter(valid).withColumn("rn", F.row_number().over(w))
     .filter("rn = 1").drop("rn")
     .withColumn("order_date", F.to_date("order_date"))
     .withColumn("is_late", F.col("delivery_hours") > F.col("promised_hours")))
(s.write.format("delta").mode("overwrite")
 .saveAsTable(f"{ns}.day19_silver"))
assert s.count() == 6
assert spark.table(f"{ns}.day19_quarantine").count() == 1
print("Silver ready: 6 orders; quarantine: 1 invalid record")
