Day 19 code
Import numbered ipynb files into Databricks. Set your own schema widget in every notebook.
Run 00_setup once, then 01_bronze, 02_silver, 03_gold.
Jobs task order: bronze, silver, gold. Job parameters: catalog, schema, simulate_failure.
04_delta_features is a separate sandbox exercise. 05_agent_function is optional.
connector_demo.py runs in a separate Python environment. airflow_day19.py needs an existing Airflow 3 environment and configured Databricks connection.
These files require the permissions and resources described in the guide. No live Azure execution is claimed.
