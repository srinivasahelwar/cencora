# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

# Optional. Requires CREATE FUNCTION on your own schema.
spark.sql(f"""CREATE OR REPLACE FUNCTION {ns}.day19_late_label(
 actual_hours DOUBLE COMMENT 'Actual delivery duration in hours',
 promised_hours DOUBLE COMMENT 'Promised delivery duration in hours')
RETURNS STRING
COMMENT 'Classify a delivery using actual and promised duration. No prediction.'
RETURN CASE
 WHEN actual_hours IS NULL OR promised_hours IS NULL THEN 'Unknown'
 WHEN actual_hours > promised_hours THEN 'Late'
 ELSE 'On time'
END""")
display(spark.sql(f"SELECT {ns}.day19_late_label(7.0, 6.0) AS result"))
