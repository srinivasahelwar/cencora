import os
import re
from databricks import sql
schema = os.environ.get("LAB_SCHEMA", "student_01")
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
with sql.connect(
    server_hostname=os.environ["DATABRICKS_SERVER_HOSTNAME"],
    http_path=os.environ["DATABRICKS_HTTP_PATH"],
    auth_type="databricks-oauth") as connection:
    with connection.cursor() as cursor:
        cursor.execute(
            f"SELECT city, revenue FROM training_lab_classic.{schema}.day19_gold "
            "WHERE revenue >= ? ORDER BY city", [700.0])
        print(cursor.fetchall())
