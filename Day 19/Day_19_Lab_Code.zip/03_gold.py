# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

s = spark.table(f"{ns}.day19_silver")
g = s.groupBy("order_date", "city").agg(
    F.count("*").alias("orders"),
    F.sum("amount").alias("revenue"),
    F.sum(F.col("is_late").cast("int")).alias("late_orders"))
g = g.withColumn("late_pct", F.round(100.0 * F.col("late_orders") / F.col("orders"), 2))
(g.write.format("delta").mode("overwrite")
 .saveAsTable(f"{ns}.day19_gold"))
r = s.agg(F.count("*").alias("n"), F.sum("amount").alias("total"),
          F.sum(F.col("is_late").cast("int")).alias("late")).first()
assert (r.n, r.total, r.late) == (6, 1400.0, 3)
display(g.orderBy("city"))
print("PASS: 6 orders, INR 1400 revenue, 3 late, 50 percent late")
