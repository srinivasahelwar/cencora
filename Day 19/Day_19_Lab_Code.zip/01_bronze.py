# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

source = spark.table(f"{ns}.day19_source")
(source.write.format("delta").mode("overwrite")
 .saveAsTable(f"{ns}.day19_bronze"))
assert spark.table(f"{ns}.day19_bronze").count() == 8
print("Bronze ready: 8 records")
