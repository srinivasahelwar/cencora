# Airflow 3.x, compatible apache-airflow-providers-databricks installed.
# Existing Databricks job parameters: catalog, schema, simulate_failure.
import pendulum
from airflow.sdk import DAG
from airflow.providers.databricks.operators.databricks import DatabricksRunNowOperator
with DAG(
    dag_id="day19_databricks_orders",
    start_date=pendulum.datetime(2026, 9, 22, tz="Asia/Kolkata"),
    schedule=None, catchup=False, max_active_runs=1,
    tags=["training", "day19"]
) as dag:
    run_orders = DatabricksRunNowOperator(
        task_id="run_orders",
        databricks_conn_id="databricks_training",
        job_id=123456,  # Replace with the existing trainer job ID.
        job_parameters={"catalog": "training_lab_classic",
                        "schema": "student_01", "simulate_failure": "false"},
        wait_for_termination=True,
        retries=0)
