# Databricks notebook source
import re
from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
ns = f"`{catalog}`.`{schema}`"
spark.sql(f"USE CATALOG `{catalog}`")
spark.sql(f"USE SCHEMA `{schema}`")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Target:", ns)

# Replaces only the day19_source table in your selected schema.
rows = [
 (1,"2026-09-21","Bengaluru",100.0,3.0,6.0,1),
 (2,"2026-09-21","Pune",200.0,7.0,6.0,2),
 (3,"2026-09-21","Bengaluru",300.0,4.0,6.0,3),
 (4,"2026-09-21","Pune",150.0,8.0,6.0,4),
 (5,"2026-09-21","Bengaluru",250.0,5.0,6.0,5),
 (6,"2026-09-21","Pune",400.0,9.0,6.0,6),
 (1,"2026-09-21","Bengaluru",100.0,3.0,6.0,7),
 (8,"2026-09-21","Pune",-50.0,2.0,6.0,8)]
fields = """order_id int, order_date string, city string,
amount double, delivery_hours double, promised_hours double,
ingest_seq int"""
source = spark.createDataFrame(rows, fields)
(source.write.format("delta").mode("overwrite")
 .saveAsTable(f"{ns}.day19_source"))
assert spark.table(f"{ns}.day19_source").count() == 8
print("Setup ready: 8 source records")
