# Databricks notebook source
import re
from pyspark.sql import functions as F
# Replace catalog with the writable catalog verified in Day 21.
dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
dbutils.widgets.text("processing_date", "2026-09-24")
cat = dbutils.widgets.get("catalog")
sch = dbutils.widgets.get("schema")
day = dbutils.widgets.get("processing_date")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", cat)
assert re.fullmatch(r"student_\d{2}", sch)
assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", day)
ns = f"{cat}.{sch}"
spark.sql(f"USE CATALOG {cat}")
spark.sql(f"USE SCHEMA {sch}")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Output namespace:", ns)

# COMMAND ----------

# All identities below are invented. This is a transformation exercise.
people = spark.createDataFrame([
 ("C001","Asha","asha@example.invalid","Bengaluru",24),
 ("C002","Ravi","ravi@example.invalid","Pune",37),
 ("C003","Meena","meena@example.invalid","Bengaluru",42)
], "customer_id STRING, name STRING, email STRING, city STRING, age INT")
people.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_customers_demo")
masked = people.select("customer_id", F.lit("REDACTED").alias("email"), "city")
display(masked)
# A mask in a DataFrame does not prevent access to the source table.

# COMMAND ----------

# Demonstrates stable pseudonyms. Unsalted SHA-256 is not an anonymity guarantee.
pseudonyms = people.select(
 F.sha2("customer_id", 256).alias("customer_token"), "city",
 (F.floor(F.col("age")/10)*10).cast("int").alias("age_band_start"))
display(pseudonyms)
# Small-domain identifiers are guessable. Production designs may use protected
# token mappings or keyed HMAC with restricted key access.
# Aggregation removes direct identifiers but small groups can still identify people.
display(people.groupBy("city").count())

# COMMAND ----------

# Disposable copy for a privacy-request simulation.
people.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_erasure_demo")
spark.sql(f"DELETE FROM {ns}.day22_erasure_demo WHERE customer_id = 'C002'")
assert spark.sql(f"SELECT COUNT(*) FROM {ns}.day22_erasure_demo "
                 "WHERE customer_id = 'C002'").first()[0] == 0
print("C002 absent from the current snapshot of this demo table")
display(spark.sql(f"DESCRIBE HISTORY {ns}.day22_erasure_demo"))
# This is logical deletion only. Source files, other tables, exports and old
# retained files may still contain the record. No VACUUM or source deletion here.
