# Databricks notebook source
import re
from pyspark.sql import functions as F
# Replace catalog with the writable catalog verified in Day 21.
dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
dbutils.widgets.text("processing_date", "2026-09-24")
cat = dbutils.widgets.get("catalog")
sch = dbutils.widgets.get("schema")
day = dbutils.widgets.get("processing_date")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", cat)
assert re.fullmatch(r"student_\d{2}", sch)
assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", day)
ns = f"{cat}.{sch}"
spark.sql(f"USE CATALOG {cat}")
spark.sql(f"USE SCHEMA {sch}")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Output namespace:", ns)

# COMMAND ----------

# Run in staggered groups on shared compute. This is synthetic data.
dbutils.widgets.text("rows", "100000")
n = int(dbutils.widgets.get("rows"))
assert 1000 <= n <= 1000000
large = (spark.range(n).select(
    F.col("id").alias("order_id"),
    (F.col("id") % 100).cast("int").alias("customer_id"),
    (F.col("id") % 4).cast("int").alias("city_id"),
    ((F.col("id") % 100) + 1).cast("decimal(12,2)").alias("amount")))
large.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_perf_orders")
print("Created", n, "synthetic rows")

# COMMAND ----------

from time import perf_counter
from statistics import median
orders = spark.table(ns+".day22_perf_orders")
cities = spark.createDataFrame([(0,"Bengaluru"),(1,"Pune"),
                               (2,"Delhi"),(3,"Mumbai")], "city_id INT, city STRING")
def query(use_broadcast=False):
    dimension = F.broadcast(cities) if use_broadcast else cities
    return (orders.filter(F.col("amount") >= 50)
            .select("city_id", "amount").join(dimension, "city_id")
            .groupBy("city").agg(F.sum("amount").alias("total")))
query(False).explain("formatted")
query(True).explain("formatted")
# Lazy transformations do not run until an action executes.
for variant in [False, True]:
    query(variant).collect()  # Warm-up, exclude from recorded trials.
measurements = {False: [], True: []}
results = {}
for trial in range(3):
    for variant in ([False, True] if trial % 2 == 0 else [True, False]):
        start = perf_counter()
        results[variant] = query(variant).orderBy("city").collect()
        measurements[variant].append(perf_counter() - start)
assert results[False] == results[True]
for variant, times in measurements.items():
    print("broadcast" if variant else "automatic", times, "median", median(times))
# The optimizer may already broadcast. A faster result is not guaranteed.

# COMMAND ----------

# Small, notebook-scoped caching experiment.
subset = orders.filter(F.col("amount") >= 50).select("city_id", "amount").cache()
try:
    start = perf_counter()
    subset.count()  # First action populates the cache.
    print("cache population seconds", perf_counter()-start)
    start = perf_counter()
    display(subset.groupBy("city_id").agg(F.sum("amount")))
    print("cached aggregation including display seconds", perf_counter()-start)
finally:
    subset.unpersist()
# Population cost and display overhead mean these two times are not an A/B speedup.

# COMMAND ----------

# Inspection is safe. Small tables might already have compact files.
display(spark.sql(f"DESCRIBE DETAIL {ns}.day22_perf_orders"))
spark.sql(f"ANALYZE TABLE {ns}.day22_perf_orders COMPUTE STATISTICS")
# Optional on your own lab table only. It performs real compute work.
spark.sql(f"OPTIMIZE {ns}.day22_perf_orders")
display(spark.sql(f"DESCRIBE DETAIL {ns}.day22_perf_orders"))
# Correctness remains unchanged.
assert spark.table(ns+".day22_perf_orders").count() == n
