# Databricks notebook source
import re
from pyspark.sql import functions as F
# Replace catalog with the writable catalog verified in Day 21.
dbutils.widgets.text("catalog", "training_lab_classic")
dbutils.widgets.text("schema", "student_01")
dbutils.widgets.text("processing_date", "2026-09-24")
cat = dbutils.widgets.get("catalog")
sch = dbutils.widgets.get("schema")
day = dbutils.widgets.get("processing_date")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", cat)
assert re.fullmatch(r"student_\d{2}", sch)
assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", day)
ns = f"{cat}.{sch}"
spark.sql(f"USE CATALOG {cat}")
spark.sql(f"USE SCHEMA {sch}")
print("Identity:", spark.sql("SELECT current_user()").first()[0])
print("Output namespace:", ns)

# COMMAND ----------

# This is Day 21's copied file. Do not overwrite it.
source = f"/Volumes/{cat}/{sch}/day21_exchange/landing/{day}/orders.csv"
print(source)
raw = (spark.read.option("header", True).option("mode", "FAILFAST")
       .schema("order_id INT, city STRING, amount DECIMAL(12,2)")
       .csv(source))
assert raw.count() == 4, "Expected the four-order Day 21 fixture"
assert raw.select("order_id").distinct().count() == 4
raw.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_bronze")
display(raw.orderBy("order_id"))

# COMMAND ----------

valid = (F.col("order_id").isNotNull() & F.col("city").isNotNull()
         & (F.length(F.trim("city")) > 0) & F.col("amount").isNotNull()
         & (F.col("amount") >= 0))
flagged = raw.withColumn("is_valid", F.coalesce(valid, F.lit(False)))
silver = flagged.filter("is_valid").drop("is_valid").withColumn("city", F.trim("city"))
rejects = flagged.filter("NOT is_valid").drop("is_valid")
assert silver.count() == 3 and rejects.count() == 1
silver.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_silver")
rejects.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_quarantine")
gold = silver.groupBy("city").agg(F.count("*").alias("orders"),
                                  F.sum("amount").alias("total_sales"))
assert float(gold.agg(F.sum("total_sales")).first()[0]) == 600.0
gold.write.format("delta").mode("overwrite").saveAsTable(ns+".day22_gold")
display(gold.orderBy("city"))

# COMMAND ----------

# SQL transformation after loading demonstrates the ELT pattern.
spark.sql(f"""CREATE OR REPLACE TABLE {ns}.day22_gold_sql USING DELTA AS
 SELECT city, COUNT(*) AS orders, SUM(amount) AS total_sales
 FROM {ns}.day22_silver GROUP BY city""")
left = spark.table(ns+".day22_gold").select("city", "orders", "total_sales")
right = spark.table(ns+".day22_gold_sql").select("city", "orders", "total_sales")
assert left.exceptAll(right).count() == 0
assert right.exceptAll(left).count() == 0
print("PASS: 4 raw, 3 valid, 1 rejected, total 600")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
    "status": "validated", "raw": 4, "valid": 3,
    "rejected": 1, "revenue": 600, "output_namespace": ns
}))
