# Day 22 lab code
Read the detailed lab guide first. No cloud execution has been performed by the author.

1. Import 01_day22_etl.ipynb, 02_day22_performance.ipynb and 03_day22_privacy.ipynb into Databricks.
2. The .py files are alternate Databricks source format. Do not import both copies.
3. Set catalog, schema and processing_date widgets to your verified Day 21 resources.
4. Run ETL first, then performance in staggered groups, then privacy.
5. The trainer separately runs 04_trainer_security.sql after replacing TRAINING_CATALOG and preparing groups.
6. Use 05_trainer_observability.sql only with authorized system-table access. Replace YOUR_WORKSPACE_ID.
7. orders_fallback.csv is only for a documented recovery exercise. Prefer the actual Day 21 copied file.

These scripts overwrite only their named day22 student tables. Security setup intentionally uses CREATE without replacement to avoid overwriting existing protected objects. Shared compute changes and privacy deletions outside the disposable demo are not automated.
