-- Trainer only. System tables require availability and explicit permissions.
-- Paste your workspace ID from the workspace URL as a string.
SELECT usage_date, sku_name, usage_unit, SUM(usage_quantity) AS quantity
FROM system.billing.usage
WHERE usage_date >= date_sub(current_date(), 7)
 AND workspace_id = 'YOUR_WORKSPACE_ID'
GROUP BY usage_date, sku_name, usage_unit
ORDER BY usage_date DESC;
-- Quantity is NOT currency. Keep distinct SKUs and units separate.
SELECT event_time, user_identity.email AS actor, service_name, action_name
FROM system.access.audit
WHERE event_date >= date_sub(current_date(), 1)
 AND workspace_id = 'YOUR_WORKSPACE_ID'
ORDER BY event_time DESC LIMIT 50;
-- Review the output privately. Audit events may contain identity information.
