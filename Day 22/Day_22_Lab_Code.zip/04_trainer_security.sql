-- TRAINER ONLY. Replace TRAINING_CATALOG with your verified catalog.
-- Create account-level groups d22_analysts and d22_privileged, then assign them
-- to the workspace. Use a test learner with no broader base-table privileges.
-- Choose a new, trainer-owned schema. Stop if this name is already in use.
CREATE SCHEMA TRAINING_CATALOG.day22_security;
CREATE TABLE TRAINING_CATALOG.day22_security.customers_private
(customer_id STRING, email STRING, region STRING) USING DELTA;
INSERT INTO TRAINING_CATALOG.day22_security.customers_private VALUES
 ('C001','asha@example.invalid','South'),
 ('C002','ravi@example.invalid','West'),
 ('C003','meena@example.invalid','South');
CREATE VIEW TRAINING_CATALOG.day22_security.customers_masked AS
SELECT customer_id,
 CASE WHEN is_account_group_member('d22_privileged') THEN email
      ELSE 'REDACTED' END AS email,
 region
FROM TRAINING_CATALOG.day22_security.customers_private
WHERE is_account_group_member('d22_privileged') OR region = 'South';
GRANT USE CATALOG ON CATALOG TRAINING_CATALOG TO `d22_analysts`;
GRANT USE SCHEMA ON SCHEMA TRAINING_CATALOG.day22_security TO `d22_analysts`;
GRANT SELECT ON VIEW TRAINING_CATALOG.day22_security.customers_masked TO `d22_analysts`;
GRANT USE CATALOG ON CATALOG TRAINING_CATALOG TO `d22_privileged`;
GRANT USE SCHEMA ON SCHEMA TRAINING_CATALOG.day22_security TO `d22_privileged`;
GRANT SELECT ON VIEW TRAINING_CATALOG.day22_security.customers_masked TO `d22_privileged`;
-- Do not grant either group SELECT on the private table.
-- Review inherited privileges. A schema or catalog SELECT grant can bypass
-- a view-only design through direct base-table access.
SHOW GRANTS ON CATALOG TRAINING_CATALOG;
SHOW GRANTS ON SCHEMA TRAINING_CATALOG.day22_security;
SHOW GRANTS ON TABLE TRAINING_CATALOG.day22_security.customers_private;
-- Run separately in each TEST USER session:
SELECT current_user(), is_account_group_member('d22_privileged');
SELECT * FROM TRAINING_CATALOG.day22_security.customers_masked;
-- Analyst: 2 South rows, REDACTED. Privileged: 3 rows, original fake emails.
-- Both non-owner test users: this query must be denied:
SELECT * FROM TRAINING_CATALOG.day22_security.customers_private;
