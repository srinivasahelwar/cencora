"""Teaching demo only: custom fixed orchestration with Azure AI Search + Azure OpenAI.
Requires a completed import wizard, a valid vectorizer on text_vector, and Azure RBAC.
Set the environment variables in your shell. All sample business data is fictional.
"""
import os
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizableTextQuery
from openai import AzureOpenAI

SEARCH_ENDPOINT = os.environ["SEARCH_ENDPOINT"]
SEARCH_INDEX = os.environ["SEARCH_INDEX"]
OPENAI_ENDPOINT = os.environ["AZURE_OPENAI_ENDPOINT"]
CHAT_DEPLOYMENT = os.environ["CHAT_DEPLOYMENT"]
API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
credential = DefaultAzureCredential(exclude_interactive_browser_credential=True)
search = SearchClient(endpoint=SEARCH_ENDPOINT, index_name=SEARCH_INDEX, credential=credential)
provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")
llm = AzureOpenAI(azure_endpoint=OPENAI_ENDPOINT, api_version=API_VERSION, azure_ad_token_provider=provider)

def answer(question):
    # Azure Search uses the index's configured query-time vectorizer.
    hits = search.search(
        search_text=question,
        vector_queries=[VectorizableTextQuery(text=question, k_nearest_neighbors=5, fields="text_vector")],
        select=["chunk", "title"],
        top=5,
    )
    context = []
    for i, doc in enumerate(hits, 1):
        context.append(f"[{i}] SOURCE: {doc.get('title', 'Unknown')}\n{doc.get('chunk', '')}")
    grounded_context = "\n\n".join(context)
    system = ("Answer only from supplied retrieved training documents. "
              "If the documents do not contain the answer, say so. "
              "Do not provide real clinical instructions. Cite [source numbers].")
    prompt = f"QUESTION: {question}\n\nRETRIEVED TRAINING CONTEXT:\n{grounded_context}"
    response = llm.chat.completions.create(
        model=CHAT_DEPLOYMENT,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
        temperature=0,
    )
    print("\nANSWER:\n", response.choices[0].message.content)
    print("\nRETRIEVED SOURCE TITLES:\n", "\n".join(context)[:2000])

if __name__ == "__main__":
    question = input("Ask a question about PX-101 (synthetic lab): ").strip()
    answer(question)
