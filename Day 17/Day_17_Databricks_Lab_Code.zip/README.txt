DAY 17 RETAIL TRAINING CODE PACK

1. Complete Lab 1 and Lab 2 permissions and volume setup first.
2. Import the six .ipynb notebooks into your own Day17 workspace folder.
3. Set the schema widget in EVERY notebook to your assigned student_XX.
4. Run 00_setup, 01_ingest, 02_clean, 03_publish, then 04_explore.
5. Run 05_delta_demo separately. It changes only day17_merge_demo.
6. Schedule ONLY 01_ingest, 02_clean and 03_publish, in that order.
7. The full source snapshot is deliberately overwritten on each run.
   All write targets are isolated day17 objects in the selected namespace.
8. SQL examples use student_01. Replace it before running.
9. Example revenue is INR. Main total 102900. Delta demo total 103700.
10. Libraries and cloud permissions depend on the training environment.
    Rehearse on Databricks before delivery. Pause schedules afterward.

Input data are invented for training. No external system or secret is needed.
