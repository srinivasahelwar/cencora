-- Replace student_01 with your assigned schema.

WITH distinct_source AS (
  SELECT DISTINCT *
  FROM training_lab.student_01.day17_bronze_orders
), typed AS (
  SELECT TRIM(order_id) AS order_id,
         TRIM(customer_id) AS customer_id,
         TRIM(product) AS product, TRIM(category) AS category,
         TRY_CAST(quantity AS INT) AS quantity,
         TRY_CAST(unit_price AS DECIMAL(12,2)) AS unit_price,
         TRY_CAST(order_date AS DATE) AS order_date
  FROM distinct_source
)
SELECT *, CAST(quantity * unit_price AS DECIMAL(18,2)) AS total_amount
FROM typed
WHERE order_id IS NOT NULL AND order_id <> ''
  AND customer_id IS NOT NULL AND customer_id <> ''
  AND product IS NOT NULL AND product <> ''
  AND category IS NOT NULL AND category <> ''
  AND quantity > 0 AND unit_price >= 0
  AND order_date IS NOT NULL;

SELECT category, COUNT(*) AS orders, SUM(quantity) AS units,
       SUM(total_amount) AS revenue
FROM training_lab.student_01.day17_silver_orders
GROUP BY category
ORDER BY category;

SELECT order_id, category, total_amount,
       ROW_NUMBER() OVER (
         PARTITION BY category
         ORDER BY total_amount DESC, order_id
       ) AS position
FROM training_lab.student_01.day17_silver_orders;

SELECT order_id, order_date, category, city,
       quantity, total_amount
FROM training_lab.student_01.day17_gold_order_detail;