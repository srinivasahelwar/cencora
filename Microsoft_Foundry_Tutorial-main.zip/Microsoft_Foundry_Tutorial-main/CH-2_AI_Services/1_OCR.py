import json
import os
from urllib.parse import urlparse

from dotenv import load_dotenv
from azure.ai.contentunderstanding import ContentUnderstandingClient
from azure.ai.contentunderstanding.models import AnalysisInput, AnalysisResult
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import AzureError
from azure.identity import DefaultAzureCredential

# Load environment variables from .env file
load_dotenv()

endpoint = os.environ["project_endpoint"]
key = os.environ["API_KEY"]


def is_absolute_url(value: str) -> bool:
    parsed_url = urlparse(value)
    return bool(parsed_url.scheme and parsed_url.netloc)


def main() -> None:
    # Insert the following configurations.

    # 3) FILE_URL - you can replace this with your own URL.
    file_url = "https://raw.githubusercontent.com/Azure-Samples/azure-ai-content-understanding-assets/main/document/invoice.pdf"

    # ANALYZER_ID - the ID of the analyzer to use.
    analyzer_id = "prebuilt-read"

    # API_VERSION - the API version to use.
    api_version = "2026-06-01-preview"

    if not is_absolute_url(endpoint):
        print("[Error] Invalid Endpoint. Please provide a valid 'Endpoint'.")
        return

    if not is_absolute_url(file_url):
        print("[Error] Invalid File URL. Please provide a valid URL.")
        return

    # Set up Content Understanding client.
    credential = AzureKeyCredential(key) if key else DefaultAzureCredential()
    client = ContentUnderstandingClient(endpoint=endpoint, credential=credential, api_version=api_version)

    # [START analyze]
    print(f"Analyzing with {analyzer_id} analyzer...")
    print(f"  File URL: {file_url}\n")

    try:
        poller = client.begin_analyze(
            analyzer_id=analyzer_id,
            inputs=[AnalysisInput(url=file_url)],
        )
        result: AnalysisResult = poller.result()
    except AzureError as err:
        print(f"[Azure Error]: {err.message}")
        return
    except Exception as ex:
        print(f"[Unexpected Error]: {ex}")
        return
    # [END analyze]

    # [START output_result]
    print("=" * 50)
    print("Analysis result:")
    print("=" * 50 + "\n")

    max_display_lines = 50
    result_str = json.dumps(result.as_dict(), indent=2)
    ret_lines = result_str.splitlines()

    # Writing the results to a file
    with open("analysis_result.json", "w") as f:
        f.write(json.dumps(result.as_dict(), indent=2))

    # if len(ret_lines) > max_display_lines:
    #     print("\n".join(ret_lines[:max_display_lines]))
    #     print(f"\n {len(ret_lines) - max_display_lines} more lines to be displayed...\n")
    # else:
    #     print(result_str)
    # [END output_result]


if __name__ == "__main__":
    main()