from openai import OpenAI
import os
from dotenv import load_dotenv
load_dotenv()

client = OpenAI(
    base_url="https://<your-resource-name>.services.ai.azure.com/api/projects/FoundryProject/openai/v1",
    api_key=os.getenv("API_KEY"),
)

input = input("Enter your message: ")

response = client.responses.create(
    input=input,
    extra_body={
        "agent_reference": {
            "name": "firstagent",
            "version": "7",
            "type": "agent_reference",
        }
    },
)

print(response.output_text)