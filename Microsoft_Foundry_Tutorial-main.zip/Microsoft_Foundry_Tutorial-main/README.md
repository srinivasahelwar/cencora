# Microsoft Foundry Tutorial

A comprehensive tutorial project demonstrating how to build intelligent applications using **Microsoft Azure AI Foundry**, covering LLMs, AI services, and autonomous agents.

## Full Tutorial
 - https://youtu.be/nuQtFrewR0o?si=LQ0gxp6Ys5Lb9LjQ

## 📋 Overview

This tutorial walks through the essential components of building AI-powered applications on Azure. It's structured in progressive chapters that build upon each other, starting from basic LLM interactions and advancing to building sophisticated multi-tool agents.

### What is Azure AI Foundry?

[Azure AI Foundry](https://learn.microsoft.com/en-us/azure/ai-studio/what-is-ai-studio) is Microsoft's platform for building, testing, and deploying AI applications at scale. It provides:

- **Unified AI Project Experience**: Manage all your AI resources in one place
- **Model Deployment**: Easy access to cutting-edge LLMs like GPT-4, Luna, and others
- **Tool Integration**: Seamlessly connect to multiple AI services
- **Agent Framework**: Build and deploy autonomous AI agents with tool-calling capabilities
- **Secure Authentication**: Enterprise-grade security and API key management

## 📁 Project Structure

```
foundry-tutorial/
├── CH-1_Models/              # Chapter 1: Foundation with Language Models
│   ├── 1_llms.py             # Basic LLM API calls with OpenAI client
│   ├── 2_Langchain_LLM.py    # Using Langchain for LLM orchestration
│   └── ...
├── CH-2_AI_Services/         # Chapter 2: Azure AI Services Integration
│   ├── 1_OCR.py              # Optical Character Recognition
│   ├── 2_STT.py              # Speech-to-Text
│   ├── 3_TTS.py              # Text-to-Speech
│   ├── 4_AISearch.ipynb      # AI-powered search capabilities
│   └── ...
├── CH-3_Agent/               # Chapter 3: Building Autonomous Agents
│   ├── 1_foundry_agent.py    # Interactive multi-tool agent example
│   └── ...
├── SampleData/               # Sample datasets for examples
├── Notes/                    # Reference notes and documentation
├── main.py                   # Quick start example
├── requirements.txt          # Python dependencies
├── pyproject.toml           # Project configuration
└── README.md                # This file
```

## 🚀 Getting Started

### Prerequisites

- **Python 3.12+** (as specified in pyproject.toml)
- **Azure Account** with access to Azure AI Foundry
- **Azure AI Project** created in your Foundry workspace
- **API Key** from your Azure AI resource

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd Foundry_Tutorial
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv venv
   source venv/Scripts/activate  # On Windows
   # or
   source venv/bin/activate      # On macOS/Linux
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

   Or using the project configuration:
   ```bash
   pip install -e .
   ```

### Environment Configuration

Create a `.env` file in the project root with your Azure credentials:

```env
API_KEY=your_azure_api_key_here
llm_endpoint=https://your-resource.services.ai.azure.com/api/openai/v1
```

**⚠️ Security Note**: Never commit your `.env` file or API keys to version control. Add `.env` to your `.gitignore`.

## 📚 Chapter Breakdown

### Chapter 1: Models & LLMs
Learn the fundamentals of working with Large Language Models through Azure AI Foundry.

- **Basic LLM Calls** (`1_llms.py`)
  - Direct API calls using the OpenAI client library
  - Querying models like GPT-5.6 Luna deployment
  - Parsing and displaying responses

- **Langchain Integration** (`2_Langchain_LLM.py`)
  - Using Langchain for advanced LLM orchestration
  - Prompt chaining and composition
  - Response processing workflows

### Chapter 2: AI Services
Explore Azure's comprehensive AI services for different modalities.

- **OCR (Optical Character Recognition)** - Extract text from images
- **STT (Speech-to-Text)** - Convert audio to text
- **TTS (Text-to-Speech)** - Convert text to natural-sounding audio
- **AI Search** - Intelligent search powered by Azure AI

### Chapter 3: Agents
Build sophisticated autonomous agents that can use multiple tools and interact intelligently.

- **Foundry Agent Example** - Create an interactive agent that:
  - Accepts user input
  - Routes queries to appropriate tools
  - Returns contextual, multi-step responses
  - Manages conversation state

## 💻 Quick Start Example

Run the basic example to interact with your first agent:

```bash
python main.py
```

This will prompt you to enter a question and send it to your configured Foundry agent.

### Example: Asking the Agent a Question
```
Enter your message: How many job roles we have in contoso
> The agent retrieves information and responds...
```

## 🔧 Running Individual Examples

```bash
# Chapter 1: Basic LLM
python CH-1_Models/1_llms.py

# Chapter 1: Langchain Integration
python CH-1_Models/2_Langchain_LLM.py

# Chapter 3: Interactive Agent
python CH-3_Agent/1_foundry_agent.py
```

For Jupyter notebooks (e.g., AI Search):
```bash
jupyter notebook CH-2_AI_Services/4_AISearch.ipynb
```

## 📦 Key Dependencies

| Package | Purpose |
|---------|---------|
| `azure-ai-projects` | Azure AI Foundry SDK and agent framework |
| `openai` | OpenAI SDK for API compatibility |
| `langchain` | LLM orchestration and chaining |
| `langchain-azure-ai` | Azure-specific Langchain integrations |
| `langchain-openai` | OpenAI provider for Langchain |
| `python-dotenv` | Environment variable management |

See `requirements.txt` for complete dependency list and versions.

## 🎯 Learning Outcomes

By completing this tutorial, you'll understand:

✅ How to authenticate and connect to Azure AI Foundry  
✅ Making API calls to Large Language Models  
✅ Orchestrating LLM workflows with Langchain  
✅ Integrating multimodal AI services (vision, speech, search)  
✅ Building and deploying autonomous agents with tool-calling  
✅ Handling API responses and error management  
✅ Production-ready patterns and best practices  

## 📖 Additional Resources

- [Azure AI Foundry Documentation](https://learn.microsoft.com/en-us/azure/ai-studio/)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
- [Langchain Documentation](https://python.langchain.com/)
- [Azure AI Services Overview](https://learn.microsoft.com/en-us/azure/ai-services/)

## 🤝 Contributing

Feel free to extend this tutorial with:
- Additional examples and use cases
- Explanatory notes in the `Notes/` folder
- Sample data files in `SampleData/`
- Improvements to existing code

## 📝 License

This tutorial project is provided as-is for educational purposes.

## 🆘 Troubleshooting

### Common Issues

**Issue**: `ModuleNotFoundError: No module named 'openai'`
- **Solution**: Ensure all dependencies are installed: `pip install -r requirements.txt`

**Issue**: `AuthenticationError` when calling API
- **Solution**: Verify your `.env` file contains the correct `API_KEY` and `llm_endpoint`

**Issue**: Agent returns empty response
- **Solution**: Check that your agent reference name and version match your Foundry project configuration

## 💡 Tips

- Start with Chapter 1 to understand the basics
- Use the `.env` file template provided to configure your credentials securely
- Experiment with different prompts and agent configurations
- Check the `Notes/` folder for implementation tips and explanations

---

**Happy learning with Azure AI Foundry!** 🚀
