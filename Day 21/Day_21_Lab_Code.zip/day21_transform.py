# Databricks notebook source
import re, json
from pyspark.sql import functions as F
for name, default in [
    ("catalog", "training_lab_classic"),
    ("schema", "student_01"),
    ("processing_date", "2026-09-24"),
    ("run_id", "manual01"),
    ("simulate_failure", "false")
]:
    dbutils.widgets.text(name, default)
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
day = dbutils.widgets.get("processing_date")
run_id = dbutils.widgets.get("run_id")
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", catalog)
assert re.fullmatch(r"student_(0[1-9]|1[0-4])", schema)
assert re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", day)
assert re.fullmatch(r"[A-Za-z0-9_-]+", run_id)
ns = f"{catalog}.{schema}"
base = f"/Volumes/{catalog}/{schema}/day21_exchange"
input_file = f"{base}/landing/{day}/orders.csv"
report_path = f"{base}/reporting/{day}/{run_id}"
print("Executing identity:",
      spark.sql("SELECT current_user()").first()[0])
print("Input:", input_file)
print("Report:", report_path)

# COMMAND ----------
if dbutils.widgets.get("simulate_failure").lower() == "true":
    raise RuntimeError("Intentional classroom failure before writes")
raw = (spark.read.option("header", True)
       .option("mode", "FAILFAST")
       .schema("order_id INT, city STRING, amount DOUBLE")
       .csv(input_file))
assert raw.count() == 4, "This exercise expects the four-row sample"
raw.write.format("delta").mode("overwrite").saveAsTable(
    f"{ns}.day21_bronze")
valid = F.coalesce(
    F.col("order_id").isNotNull() &
    F.col("city").isNotNull() &
    (F.length(F.trim("city")) > 0) &
    F.col("amount").isNotNull() &
    (~F.isnan("amount")) & (F.col("amount") >= 0),
    F.lit(False))
clean = raw.filter(valid).withColumn("city", F.trim("city"))
rejects = raw.filter(~valid)
assert clean.count() == 3
assert rejects.count() == 1
assert clean.select("order_id").distinct().count() == clean.count()
summary = clean.groupBy("city").agg(
    F.count("*").alias("orders"),
    F.sum("amount").alias("total_sales"))
expected = {"Bengaluru": (2, 400.0), "Pune": (1, 200.0)}
actual = {r.city: (r.orders, r.total_sales)
          for r in summary.collect()}
assert actual == expected, actual
rejects.write.format("delta").mode("overwrite").saveAsTable(
    f"{ns}.day21_quarantine")
clean.write.format("delta").mode("overwrite").saveAsTable(
    f"{ns}.day21_silver")
summary.write.format("delta").mode("overwrite").saveAsTable(
    f"{ns}.day21_gold")
# Separate reporting export, not the internal files of a Delta table.
summary.write.mode("overwrite").parquet(report_path)
display(summary.orderBy("city"))

# COMMAND ----------
dbutils.notebook.exit(json.dumps({
    "status": "validated",
    "raw_rows": 4, "valid_rows": 3, "rejected_rows": 1,
    "revenue": 600.0, "report_path": report_path,
    "run_id": run_id
}))
