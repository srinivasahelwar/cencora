-- Trainer: substitute verified catalog, student and principal.
CREATE EXTERNAL VOLUME IF NOT EXISTS
  training_lab_classic.student_01.day21_exchange
LOCATION 'abfss://day21@stcdgtraininglab01.dfs.core.windows.net/student_01';
GRANT USE CATALOG ON CATALOG training_lab_classic TO `PRINCIPAL`;
GRANT USE SCHEMA ON SCHEMA training_lab_classic.student_01
  TO `PRINCIPAL`;
GRANT CREATE TABLE ON SCHEMA training_lab_classic.student_01
  TO `PRINCIPAL`;
GRANT READ VOLUME, WRITE VOLUME ON VOLUME
  training_lab_classic.student_01.day21_exchange TO `PRINCIPAL`;
