Day 21 code pack
Read the lab guide first. Import either notebook format. All resource names are examples requiring verification. No secrets are included. Cloud execution is not verified. Run the pipeline with the assigned schema and retain the successful run ID for the Synapse query. Do not query all run folders together.
