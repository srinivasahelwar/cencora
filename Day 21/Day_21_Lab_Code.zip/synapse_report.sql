-- Run in Synapse Studio, Built-in SQL, signed in with Entra ID.
-- Replace STUDENT, DATE and RUN_ID with this successful run.
SELECT city, orders, total_sales
FROM OPENROWSET(
    BULK 'https://stcdgtraininglab01.dfs.core.windows.net/day21/STUDENT/reporting/DATE/RUN_ID/*.parquet',
    FORMAT = 'PARQUET'
) WITH (
    city varchar(100),
    orders bigint,
    total_sales float
) AS sales
ORDER BY city;
